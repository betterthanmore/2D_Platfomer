public class KeyMap
{
    public enum KEYTYPE
    {
        GamePad1_A,
        GamePad2_A,
        GamePad1_B,
        GamePad2_B,
        GamePad1_X,
        GamePad2_X,
        GamePad1_Y,
        GamePad2_Y,
        GamePad1_LB,
        GamePad2_LB,
        GamePad1_RB,
        GamePad2_RB,
        GamePad1_LT,
        GamePad2_LT,
        GamePad1_RT,
        GamePad2_RT,
        GamePad1_START,
        GamePad2_START,
        Horizontal1,
        Horizontal2,
        Vertical1,
        Vertical2

    }

}
